extends Control
## BurgerView — komposer: burger + kertas 3D (SubViewport transparan) di bawah, efek 2D (BurgerFX) di atas.
## API publik sama seperti versi 2D, jadi main.gd tidak perlu tahu bedanya.
## Animasi: burger masuk dari kiri, kertas dilipat (bawah -> kiri/kanan -> atas) MENGELILINGI burger,
## stempel "HUSH BURGER", lalu bungkusan didorong keluar ke kiri.

const UiKit := preload("res://scripts/ui_kit.gd")
const Item := preload("res://scripts/burger_item_3d.gd")
const Fx := preload("res://scripts/burger_fx.gd")
const Canvas := preload("res://scripts/burger_canvas.gd")

const FOLD_TIME := 0.34
const ENTER_TIME := 0.40
const LEAVE_TIME := 0.45
const FOLDS: Array = ["bottom", "left", "right", "top"]

const PITCH_DEG := 64.0
const WORLD_SCALE := 0.88

## Offset guncangan layar (diatur oleh Main).
var view_offset: Vector2 = Vector2.ZERO:
	set(v):
		view_offset = v
		_layout()

var skin_color: Color = Color.WHITE
var max_lives: int = 3:
	set(v):
		max_lives = v
		if _fx:
			_fx.max_lives = v
var lives: int = 3:
	set(v):
		lives = v
		if _fx:
			_fx.lives = v
var show_lives: bool = true:
	set(v):
		show_lives = v
		if _fx:
			_fx.show_lives = v

var _canvas: Control
var _fx: Control
var _item = null
var _leaving: Array = []
var _fold_p: Dictionary = {"bottom": 0.0, "left": 0.0, "right": 0.0, "top": 0.0}
var _fold_t: Dictionary = {"bottom": 0.0, "left": 0.0, "right": 0.0, "top": 0.0}
var _enter: float = 1.0
var _bump: float = 0.0
var _wiggle: float = 0.0
var _clock: float = 0.0
var _span: float = 5.0   # jarak masuk/keluar (satuan dunia)


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_build()
	resized.connect(_layout)
	_layout()


func _build() -> void:
	_canvas = Canvas.new()
	add_child(_canvas)
	_canvas.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	_fx = Fx.new()
	add_child(_fx)
	_fx.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_fx.max_lives = max_lives
	_fx.lives = lives
	_fx.show_lives = show_lives


## Pasang kamera di sekitar pusat burger.
func _layout() -> void:
	if _canvas == null or size.x < 10.0:
		return
	var c := UiKit.burger_center(size)
	var r := UiKit.burger_radius(size)
	var ppu := r * WORLD_SCALE
	_canvas.setup(c + view_offset, ppu, PITCH_DEG)
	_span = size.x * 0.5 / ppu + 1.9


# ------------------------------------------------------------------ API publik
func set_skin(c: Color) -> void:
	skin_color = c
	if _item:
		_item.set_paper_color(c)


## Mulai ronde/tampilan siap: burger pertama sudah ada di tengah (tanpa animasi masuk).
func start_round(with_burger: bool) -> void:
	_leaving.clear()
	_item = null
	_fx.clear()
	_reset_folds()
	_enter = 1.0
	_bump = 0.0
	_wiggle = 0.0
	if with_burger:
		_make_item()
	_apply()


## Langkah 1: kertas + burger baru meluncur masuk dari kiri.
func new_burger() -> void:
	if _item:
		_push_leaving("serve")
	_reset_folds()
	_make_item()
	_enter = 0.0
	_apply()


## which: "bottom" | "left" | "right" | "top"
func fold(which: String) -> void:
	if _item == null:
		return
	_fold_t[which] = 1.0
	_bump = 1.0
	_fx.spawn(6, false)
	if which == "top":
		_fx.spawn(14, true) # bungkusan rapat -> sedikit konfeti


## Langkah 5 (selesai): bungkusan didorong keluar ke kiri.
func serve() -> void:
	_push_leaving("serve")
	_fx.popup(_txt_plus(), Color(1.0, 0.82, 0.25))
	_fx.spawn(18, true)


## Kirim paksa sebelum selesai (nyawa -1).
func discard() -> void:
	_push_leaving("discard")
	_fx.popup(_txt_minus(), Color(1.0, 0.3, 0.3))


## Gesture tidak berlaku: kertas bergoyang sebentar.
func wiggle() -> void:
	_wiggle = 1.0


func set_lives(n: int) -> void:
	lives = n


func popup(text: String, col: Color) -> void:
	_fx.popup(text, col)


func burst(count: int) -> void:
	_fx.spawn(count, true)


func _txt_plus() -> String: return Loc.t("pop_plus")
func _txt_minus() -> String: return Loc.t("pop_minus")


# ------------------------------------------------------------------ Internal
func _make_item() -> void:
	_item = Item.new(skin_color)


func _reset_folds() -> void:
	for k in FOLDS:
		_fold_p[k] = 0.0
		_fold_t[k] = 0.0


func _push_leaving(kind: String) -> void:
	if _item:
		if kind == "discard":
			_item.set_paper_color(skin_color.lerp(Color(1.0, 0.3, 0.3), 0.55))
		_leaving.append({"node": _item, "t": 0.0})
	_item = null
	_reset_folds()


## Pasang animasi (posisi, goyang, lipatan) ke item aktif.
func _apply() -> void:
	if _item == null:
		_sync_canvas()
		return
	var ek := 1.0 - pow(1.0 - _enter, 3.0)
	_item.pos = Vector3(-(1.0 - ek) * _span, 0.0, 0.0)
	_item.scl = Vector3(1.0 + 0.05 * _bump, 1.0 - 0.06 * _bump, 1.0 + 0.05 * _bump)
	_item.yaw = sin(_clock * 45.0) * 0.12 * _wiggle
	_item.set_folds(_fold_p_eased())
	_sync_canvas()


func _sync_canvas() -> void:
	var list: Array = []
	for lv in _leaving:
		list.append(lv["node"])
	if _item:
		list.append(_item)
	_canvas.items = list
	_canvas.queue_redraw()


func _fold_p_eased() -> Dictionary:
	var d := {}
	for k in FOLDS:
		d[k] = _e(float(_fold_p[k]))
	return d


## Easing "bouncy": melewati 1 sedikit (+-5%) lalu kembali.
func _e(p: float) -> float:
	var t := p - 1.0
	return 1.0 + 2.2 * t * t * t + 1.2 * t * t


func _process(delta: float) -> void:
	if not is_visible_in_tree():
		return
	_clock += delta
	for k in FOLDS:
		_fold_p[k] = move_toward(float(_fold_p[k]), float(_fold_t[k]), delta / FOLD_TIME)
	if _enter < 1.0:
		_enter = minf(1.0, _enter + delta / ENTER_TIME)
	_bump = maxf(0.0, _bump - delta * 6.0)
	_wiggle = maxf(0.0, _wiggle - delta * 3.5)
	_apply()

	var i := _leaving.size() - 1
	while i >= 0:
		var lv: Dictionary = _leaving[i]
		lv["t"] = float(lv["t"]) + delta
		var k: float = float(lv["t"]) / LEAVE_TIME
		var node = lv["node"]
		if k >= 1.0:
			_leaving.remove_at(i)
		else:
			node.pos = Vector3(-k * k * _span, sin(k * PI) * 0.25, 0.0)
			node.yaw = k * k * 0.5
		i -= 1
	_sync_canvas()
