extends RefCounted
## WrapSystem — aturan urutan membungkus satu burger. Murni logika (tanpa gambar).
##
## Urutan satu burger (6 swipe):
##   1. BURGER BARU   : 1 jari, geser ke kiri   (kertas + burger muncul dari kiri)
##   2. LIPAT BAWAH   : 2 jari, geser ke atas
##   3a. LIPAT KIRI   : 2 jari, geser ke kanan  (kiri -> kanan)
##   3b. LIPAT KANAN  : 1 jari, geser ke kiri   (kanan -> kiri)   (3a / 3b boleh urutan apa saja)
##   4. LIPAT ATAS    : 2 jari, geser ke bawah
##   5. KIRIM         : 1 jari, geser ke kiri   (burger selesai pindah ke kiri = +1 burger)
## Kirim paksa (burger belum selesai) : 2 jari, geser ke kiri -> nyawa -1.
## Di awal ronde burger pertama sudah ada (langkah 1 dilewati).

const Gesture := preload("res://scripts/gesture_detector.gd")

enum Action { INVALID, NEW_BURGER, FOLD_BOTTOM, FOLD_LEFT, FOLD_RIGHT, FOLD_TOP, SERVE, DISCARD }

var has_burger: bool = false
var bottom: bool = false
var left: bool = false
var right: bool = false
var top: bool = false


func reset(with_burger: bool) -> void:
	has_burger = with_burger
	_clear_folds()


func _clear_folds() -> void:
	bottom = false
	left = false
	right = false
	top = false


func is_complete() -> bool:
	return has_burger and bottom and left and right and top


## Proses satu swipe. Mengembalikan Action; INVALID = gesture tidak berlaku sekarang (tanpa hukuman).
func handle(fingers: int, dir: int) -> int:
	var D := Gesture.Dir
	if fingers == 2 and dir == D.UP:
		if has_burger and not bottom:
			bottom = true
			return Action.FOLD_BOTTOM
	elif fingers == 2 and dir == D.RIGHT:
		if has_burger and bottom and not left:
			left = true
			return Action.FOLD_LEFT
	elif fingers == 2 and dir == D.DOWN:
		if has_burger and bottom and left and right and not top:
			top = true
			return Action.FOLD_TOP
	elif fingers == 2 and dir == D.LEFT:
		if has_burger:
			var done := is_complete()
			has_burger = false
			_clear_folds()
			return Action.SERVE if done else Action.DISCARD
	elif fingers == 1 and dir == D.LEFT:
		if not has_burger:
			has_burger = true
			_clear_folds()
			return Action.NEW_BURGER
		if bottom and not right:
			right = true
			return Action.FOLD_RIGHT
		if is_complete():
			has_burger = false
			_clear_folds()
			return Action.SERVE
	return Action.INVALID


## Petunjuk gesture berikutnya yang sebaiknya dilakukan pemain.
func next_hint() -> Dictionary:
	var D := Gesture.Dir
	if not has_burger:
		return {"fingers": 1, "dir": D.LEFT, "text": "h_new"}
	if not bottom:
		return {"fingers": 2, "dir": D.UP, "text": "h_bottom"}
	if not left:
		return {"fingers": 2, "dir": D.RIGHT, "text": "h_left"}
	if not right:
		return {"fingers": 1, "dir": D.LEFT, "text": "h_right"}
	if not top:
		return {"fingers": 2, "dir": D.DOWN, "text": "h_top"}
	return {"fingers": 1, "dir": D.LEFT, "text": "h_send"}
