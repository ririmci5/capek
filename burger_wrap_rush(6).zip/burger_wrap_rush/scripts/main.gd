extends Control
## Main — merakit UI dan menghubungkan GameManager, TimerSystem, ClickCounter (hitung swipe),
## GestureDetector, WrapSystem, BurgerView, ScrollVideoView, UpgradeShop.
## Alur: IDLE (siap, swipe valid pertama memulai) -> PLAYING (20 dtk / 3 nyawa) -> RESULT.
## Dua mode: BURGER (wrap bertahap dengan swipe) dan SCROLL (swipe 1 jari ke atas = video baru).

enum State { IDLE, PLAYING, RESULT }
enum Mode { BURGER, SCROLL }

const UiKit := preload("res://scripts/ui_kit.gd")
const TimerSystem := preload("res://scripts/timer_system.gd")
const ClickCounter := preload("res://scripts/click_counter.gd")
const BurgerView := preload("res://scripts/burger_view.gd")
const TableView := preload("res://scripts/table_view.gd")
const UpgradeShop := preload("res://scripts/upgrade_shop.gd")
const LanguagePicker := preload("res://scripts/language_picker.gd")
const Sfx := preload("res://scripts/sfx.gd")
const Gesture := preload("res://scripts/gesture_detector.gd")
const WrapSystem := preload("res://scripts/wrap_system.gd")
const GestureHint := preload("res://scripts/gesture_hint.gd")
const ScrollVideoView := preload("res://scripts/scroll_video_view.gd")

const ACT_ACTIVE := Color("34c759")
const ACT_INACTIVE := Color("5a5566")

var state: int = State.IDLE
var mode: int = Mode.BURGER
var burgers: int = 0          # skor ronde ini (burger terkirim / video di-scroll)
var lives: int = 3
var run_coins: float = 0.0

var _timer = null
var _clicks = null
var _sfx = null
var _wrap = null
var _gesture = null
var _shake: float = 0.0
var _last_haptic: int = 0
var _time_low: bool = false
var _blockers: Array = []   # tombol: swipe yang dimulai di atasnya diabaikan
var _last_caption: Label

var _play: Control
var _burger_view = null
var _table_view = null
var _scroll_view = null
var _hint_view = null
var _idle_box: Control
var _btn_burger: Button
var _btn_scroll: Button
var _result_box: Control
var _result_panel: Control
var _shop = null
var _lang_picker = null

var _lbl_level: Label
var _bar_xp: ProgressBar
var _lbl_coins: Label
var _lbl_gems: Label
var _lbl_subtitle: Label
var _cap_score: Label
var _val_time: Label
var _val_burgers: Label
var _val_cps: Label
var _val_best: Label
var _res_title: Label
var _res_record: Label
var _res_burgers: Label
var _res_caption: Label
var _res_coins: Label
var _res_xp: Label
var _res_gems: Label
var _res_level: Label


func _ready() -> void:
	_clicks = ClickCounter.new()
	_timer = TimerSystem.new()
	add_child(_timer)
	_timer.tick.connect(_on_tick)
	_timer.finished.connect(func(): _end_round("time"))
	_sfx = Sfx.new()
	add_child(_sfx)
	_wrap = WrapSystem.new()
	_gesture = Gesture.new()
	_gesture.start_filter = _gesture_start_ok
	_gesture.swiped.connect(_on_swipe)

	_build_ui()
	mode = GameManager.get_mode()
	_apply_mode()
	GameManager.data_changed.connect(_refresh_hud)
	_enter_idle()


# =============================================================== Input (gesture)
func _input(event: InputEvent) -> void:
	# Hanya sentuhan. Mouse di desktop jadi sentuhan lewat emulate_touch_from_mouse
	# (tahan SHIFT saat drag = 2 jari).
	if not (event is InputEventScreenTouch or event is InputEventScreenDrag):
		return
	if _shop.visible or _lang_picker.visible or state == State.RESULT:
		return
	_gesture.feed(event)


func _gesture_start_ok(te: InputEventScreenTouch) -> bool:
	var local: Vector2 = (_play.make_input_local(te) as InputEventScreenTouch).position
	if not Rect2(Vector2.ZERO, _play.size).has_point(local):
		return false
	for b in _blockers:
		if b.is_visible_in_tree():
			var bl: Vector2 = (b.make_input_local(te) as InputEventScreenTouch).position
			if Rect2(Vector2.ZERO, b.size).has_point(bl):
				return false
	return true


func _on_swipe(fingers: int, dir: int) -> void:
	if state == State.RESULT or _shop.visible or _lang_picker.visible:
		return
	if mode == Mode.BURGER:
		_swipe_burger(fingers, dir)
	else:
		_swipe_scroll(fingers, dir)


func _swipe_burger(fingers: int, dir: int) -> void:
	var act: int = _wrap.handle(fingers, dir)
	if act == WrapSystem.Action.INVALID:
		_burger_view.wiggle() # gesture tidak berlaku sekarang (tanpa hukuman)
		return
	if state == State.IDLE:
		_start_round()
	_clicks.register_tap()

	if act == WrapSystem.Action.NEW_BURGER:
		_burger_view.new_burger()
		_sfx.swipe()
		_haptic(8)
	elif act == WrapSystem.Action.SERVE:
		burgers += 1
		run_coins += GameManager.coin_value()
		_burger_view.serve()
		_sfx.serve()
		_haptic(30)
		_shake = 6.0
		_val_burgers.text = str(burgers)
		_update_coins()
	elif act == WrapSystem.Action.DISCARD:
		lives -= 1
		_burger_view.discard()
		_burger_view.set_lives(lives)
		_sfx.bad()
		_haptic(90)
		_shake = 9.0
		if lives <= 0:
			_end_round("lives")
			return
	else:
		var which := "top"
		if act == WrapSystem.Action.FOLD_BOTTOM:
			which = "bottom"
		elif act == WrapSystem.Action.FOLD_LEFT:
			which = "left"
		elif act == WrapSystem.Action.FOLD_RIGHT:
			which = "right"
		_burger_view.fold(which)
		_sfx.fold()
		_haptic(10)
		_shake = 3.0
	_update_hint()


func _swipe_scroll(fingers: int, dir: int) -> void:
	if fingers != 1 or dir != Gesture.Dir.UP:
		_scroll_view.wiggle() # hanya swipe 1 jari ke atas yang berlaku
		return
	if state == State.IDLE:
		_start_round()
	_clicks.register_tap()
	burgers += 1
	run_coins += GameManager.coin_value()
	_scroll_view.next_video()
	_sfx.swipe()
	_haptic(10)
	_val_burgers.text = str(burgers)
	_update_coins()


func _haptic(ms: int) -> void:
	if not GameManager.haptic_on():
		return
	var now := Time.get_ticks_msec()
	if now - _last_haptic < 40: # dibatasi agar swipe cepat tidak membebani motor getar
		return
	_last_haptic = now
	Input.vibrate_handheld(ms)


# =============================================================== Mode
func _on_mode_pressed(m: int) -> void:
	if state != State.IDLE or m == mode:
		return
	_sfx.click()
	mode = m
	GameManager.set_mode(m)
	_apply_mode()
	_enter_idle()


func _apply_mode() -> void:
	var is_burger := mode == Mode.BURGER
	_table_view.visible = is_burger
	_burger_view.visible = is_burger
	_burger_view.show_lives = is_burger
	_scroll_view.visible = not is_burger
	_cap_score.text = Loc.t("burgers") if is_burger else Loc.t("videos")
	UiKit.restyle_button(_btn_burger, ACT_ACTIVE if is_burger else ACT_INACTIVE)
	UiKit.restyle_button(_btn_scroll, ACT_ACTIVE if not is_burger else ACT_INACTIVE)


func _update_hint() -> void:
	if state == State.RESULT:
		_hint_view.hide_hint()
	elif mode == Mode.BURGER:
		var h: Dictionary = _wrap.next_hint()
		_hint_view.show_hint(int(h["fingers"]), int(h["dir"]), str(h["text"]))
	else:
		_hint_view.show_hint(1, Gesture.Dir.UP, "next_video")


# =============================================================== Alur ronde
func _enter_idle() -> void:
	state = State.IDLE
	burgers = 0
	lives = GameManager.MAX_LIVES
	run_coins = 0.0
	_clicks.reset()
	_timer.stop()
	_gesture.reset()
	_time_low = false
	_val_time.add_theme_color_override("font_color", UiKit.C_YELLOW)
	_val_burgers.text = "0"
	_val_cps.text = "0.0"
	_wrap.reset(true) # burger pertama langsung ada saat ronde mulai
	_burger_view.max_lives = GameManager.MAX_LIVES
	_burger_view.set_lives(lives)
	_burger_view.start_round(true)
	_scroll_view.reset_session()
	_lbl_subtitle.text = Loc.t("sub_burger") if mode == Mode.BURGER else Loc.t("sub_scroll")
	_result_box.visible = false
	_idle_box.visible = true
	_update_hint()
	_refresh_hud()


func _start_round() -> void:
	state = State.PLAYING
	burgers = 0
	run_coins = 0.0
	_clicks.reset()
	_idle_box.visible = false
	_lbl_subtitle.text = Loc.t("playing")
	_timer.start(GameManager.round_time())


func _on_tick(t: float) -> void:
	_val_time.text = "%.1f" % t
	var low := t < 5.0
	if low != _time_low:
		_time_low = low
		_val_time.add_theme_color_override("font_color", UiKit.C_RED if low else UiKit.C_YELLOW)


func _end_round(reason: String) -> void:
	if state == State.RESULT:
		return
	state = State.RESULT
	_timer.stop()
	_gesture.reset()
	_hint_view.hide_hint()
	_val_cps.text = "0.0"
	if reason == "time":
		_val_time.text = "0.0"
	_lbl_subtitle.text = Loc.t("round_over")
	var res: Dictionary = GameManager.finish_round(burgers, run_coins, mode) # simpan langsung
	res["reason"] = reason
	_sfx.end()
	await get_tree().create_timer(0.45).timeout
	_show_result(res)


func _show_result(res: Dictionary) -> void:
	_res_title.text = Loc.t("lives_out") if res["reason"] == "lives" else Loc.t("time_up")
	_res_caption.text = Loc.t("cap_burger") if mode == Mode.BURGER else Loc.t("cap_video")
	_res_burgers.text = str(res["burgers"])
	_res_record.visible = bool(res["new_best"])
	_res_coins.text = Loc.t("coins") + "  +%d" % int(res["coins"])
	_res_xp.text = "XP  +%d" % int(res["xp"])
	_res_gems.visible = int(res["gems"]) > 0
	_res_gems.text = Loc.t("gem") + "  +%d" % int(res["gems"])
	_res_level.visible = int(res["levels_gained"]) > 0
	_res_level.text = Loc.t("level_up") + "  Lv %d" % int(res["level"])
	_result_box.visible = true
	if bool(res["new_best"]):
		_sfx.win()
		_burger_view.burst(50)
	# Animasi muncul (bouncy)
	await get_tree().process_frame
	_result_panel.pivot_offset = _result_panel.size / 2.0
	_result_panel.scale = Vector2(0.6, 0.6)
	var tw := create_tween()
	tw.tween_property(_result_panel, "scale", Vector2.ONE, 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)


func _on_play_again() -> void:
	_sfx.click()
	_enter_idle()


func _open_lang() -> void:
	_sfx.click()
	_gesture.reset()
	_lang_picker.open()


func _open_shop() -> void:
	_sfx.click()
	_gesture.reset()
	_shop.open()


# =============================================================== Per frame
func _process(delta: float) -> void:
	if _shake > 0.0:
		_shake = maxf(0.0, _shake - 40.0 * delta)
		var off := Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * _shake
		_burger_view.view_offset = off
		_table_view.view_offset = off
	if state == State.PLAYING:
		_val_cps.text = "%.1f" % _clicks.cps()


# =============================================================== HUD
func _refresh_hud() -> void:
	var lvl := GameManager.get_level()
	var need := GameManager.xp_needed(lvl)
	_lbl_level.text = "LV %d   %d / %d XP" % [lvl, GameManager.get_xp(), need]
	_bar_xp.max_value = need
	_bar_xp.value = GameManager.get_xp()
	_update_coins()
	_lbl_gems.text = str(GameManager.get_gems())
	_val_best.text = str(GameManager.get_best(mode))
	_burger_view.set_skin(GameManager.get_skin_color())
	if state == State.IDLE:
		_val_time.text = "%.1f" % GameManager.round_time()


func _update_coins() -> void:
	var shown := GameManager.get_coins()
	if state == State.PLAYING:
		shown += int(round(run_coins))
	_lbl_coins.text = _fmt(shown)


func _fmt(n: int) -> String:
	if n >= 1000000:
		return "%.1fM" % (n / 1000000.0)
	if n >= 10000:
		return "%.1fK" % (n / 1000.0)
	return str(n)


# =============================================================== Membangun UI
func _safe_inset() -> Vector2: # (atas, bawah) untuk notch / bar navigasi, dalam unit viewport
	if not (OS.has_feature("android") or OS.has_feature("ios")):
		return Vector2.ZERO
	var win := DisplayServer.window_get_size()
	var vp := get_viewport_rect().size
	if win.y <= 0 or vp.y <= 0.0:
		return Vector2.ZERO
	var sc := float(win.y) / vp.y
	var safe := DisplayServer.get_display_safe_area()
	var top := maxf(0.0, float(safe.position.y)) / sc
	var bottom := maxf(0.0, float(win.y) - float(safe.position.y + safe.size.y)) / sc
	return Vector2(clampf(top, 0.0, 80.0), clampf(bottom, 0.0, 80.0))


func _pill(ratio: float) -> PanelContainer:
	var p := PanelContainer.new()
	p.add_theme_stylebox_override("panel", UiKit.style(Color("1d1a24e6"), 22, Color("ffffff30"), 2, 10))
	p.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	p.size_flags_stretch_ratio = ratio
	p.mouse_filter = Control.MOUSE_FILTER_IGNORE
	return p


func _stat_cell(grid: GridContainer, caption: String, color: Color) -> Label:
	var v := VBoxContainer.new()
	v.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	v.add_theme_constant_override("separation", -2)
	v.mouse_filter = Control.MOUSE_FILTER_IGNORE
	grid.add_child(v)
	_last_caption = UiKit.label(caption, 13, Color("9d93b5"))
	v.add_child(_last_caption)
	var val := UiKit.label("0", 40, color, 6)
	v.add_child(val)
	return val


func _build_ui() -> void:
	var inset := _safe_inset()

	var bg := ColorRect.new()
	bg.color = Color("2b2233")
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)

	var root := VBoxContainer.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_theme_constant_override("separation", 0)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)

	# ---- Pill bar: Level+XP, Koin, Gem
	var top := MarginContainer.new()
	top.add_theme_constant_override("margin_left", 14)
	top.add_theme_constant_override("margin_right", 14)
	top.add_theme_constant_override("margin_top", 12 + int(inset.x))
	top.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(top)
	var pills := HBoxContainer.new()
	pills.add_theme_constant_override("separation", 8)
	pills.mouse_filter = Control.MOUSE_FILTER_IGNORE
	top.add_child(pills)

	var lv_pill := _pill(2.0)
	var lv_box := VBoxContainer.new()
	lv_box.add_theme_constant_override("separation", 4)
	lv_pill.add_child(lv_box)
	_lbl_level = UiKit.label("LV 1   0 / 140 XP", 16, Color.WHITE, 3)
	lv_box.add_child(_lbl_level)
	_bar_xp = ProgressBar.new()
	_bar_xp.show_percentage = false
	_bar_xp.custom_minimum_size = Vector2(0, 8)
	_bar_xp.add_theme_stylebox_override("background", UiKit.style(Color("45395a"), 4, Color(0, 0, 0, 0), 0, 0))
	_bar_xp.add_theme_stylebox_override("fill", UiKit.style(UiKit.C_GREEN, 4, Color(0, 0, 0, 0), 0, 0))
	_bar_xp.mouse_filter = Control.MOUSE_FILTER_IGNORE
	lv_box.add_child(_bar_xp)
	pills.add_child(lv_pill)

	var coin_pill := _pill(1.2)
	var coin_row := HBoxContainer.new()
	coin_row.alignment = BoxContainer.ALIGNMENT_CENTER
	coin_row.add_theme_constant_override("separation", 6)
	coin_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	coin_pill.add_child(coin_row)
	coin_row.add_child(UiKit.dot(Color("ffc83d")))
	_lbl_coins = UiKit.label("0", 18, Color.WHITE, 3)
	coin_row.add_child(_lbl_coins)
	pills.add_child(coin_pill)

	var gem_pill := _pill(1.0)
	var gem_row := HBoxContainer.new()
	gem_row.alignment = BoxContainer.ALIGNMENT_CENTER
	gem_row.add_theme_constant_override("separation", 6)
	gem_row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	gem_pill.add_child(gem_row)
	gem_row.add_child(UiKit.dot(Color("5dd6ff")))
	_lbl_gems = UiKit.label("0", 18, Color.WHITE, 3)
	gem_row.add_child(_lbl_gems)
	pills.add_child(gem_pill)

	# ---- Judul
	var title_box := VBoxContainer.new()
	title_box.add_theme_constant_override("separation", -2)
	title_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(title_box)
	var gap := Control.new()
	gap.custom_minimum_size = Vector2(0, 8)
	gap.mouse_filter = Control.MOUSE_FILTER_IGNORE
	title_box.add_child(gap)
	title_box.add_child(UiKit.label("BURGER WRAP RUSH", 34, UiKit.C_YELLOW, 8))
	_lbl_subtitle = UiKit.label("", 16, Color("e8dcff"), 4)
	title_box.add_child(_lbl_subtitle)

	# ---- Area bermain (restoran + burger / video)
	_play = Control.new()
	_play.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_play.clip_contents = true
	_play.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(_play)
	_table_view = TableView.new()
	_play.add_child(_table_view)
	_table_view.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_burger_view = BurgerView.new()
	_play.add_child(_burger_view)
	_burger_view.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_scroll_view = ScrollVideoView.new()
	_play.add_child(_scroll_view)
	_scroll_view.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_hint_view = GestureHint.new()
	_play.add_child(_hint_view)
	_hint_view.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	# Overlay IDLE: pilih mode + toko
	var idle := VBoxContainer.new()
	idle.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	idle.alignment = BoxContainer.ALIGNMENT_END
	idle.add_theme_constant_override("separation", 8)
	idle.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_play.add_child(idle)
	_idle_box = idle
	var row_margin := MarginContainer.new()
	row_margin.add_theme_constant_override("margin_left", 14)
	row_margin.add_theme_constant_override("margin_right", 14)
	row_margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	idle.add_child(row_margin)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 8)
	row.mouse_filter = Control.MOUSE_FILTER_IGNORE
	row_margin.add_child(row)
	_btn_burger = UiKit.button(Loc.t("mode_burger"), ACT_ACTIVE, 20, Vector2(0, 54))
	_btn_burger.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_btn_burger.pressed.connect(_on_mode_pressed.bind(Mode.BURGER))
	row.add_child(_btn_burger)
	_btn_scroll = UiKit.button(Loc.t("mode_scroll"), ACT_INACTIVE, 20, Vector2(0, 54))
	_btn_scroll.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_btn_scroll.pressed.connect(_on_mode_pressed.bind(Mode.SCROLL))
	row.add_child(_btn_scroll)
	var shop_btn := UiKit.button(Loc.t("shop"), Color("4f8cff"), 20, Vector2(0, 54))
	shop_btn.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	shop_btn.pressed.connect(_open_shop)
	row.add_child(shop_btn)
	var lang_btn := UiKit.button(Loc.lang.to_upper(), Color("7a5cff"), 18, Vector2(64, 54))
	lang_btn.pressed.connect(_open_lang)
	row.add_child(lang_btn)
	_blockers.append_array([_btn_burger, _btn_scroll, shop_btn, lang_btn])
	var pad := Control.new()
	pad.custom_minimum_size = Vector2(0, 10)
	pad.mouse_filter = Control.MOUSE_FILTER_IGNORE
	idle.add_child(pad)

	_build_result()

	# ---- Panel statistik bawah
	var bottom := PanelContainer.new()
	var sb := UiKit.style(Color("17131d"), 28, Color("ffd23f55"), 3, 14)
	sb.corner_radius_bottom_left = 0
	sb.corner_radius_bottom_right = 0
	bottom.add_theme_stylebox_override("panel", sb)
	root.add_child(bottom)
	var bv := VBoxContainer.new()
	bottom.add_child(bv)
	var grid := GridContainer.new()
	grid.columns = 4
	grid.add_theme_constant_override("h_separation", 6)
	bv.add_child(grid)
	_val_time = _stat_cell(grid, Loc.t("time_left"), UiKit.C_YELLOW)
	_val_burgers = _stat_cell(grid, Loc.t("burgers"), UiKit.C_GREEN)
	_cap_score = _last_caption
	_val_cps = _stat_cell(grid, Loc.t("swipe_s"), UiKit.C_YELLOW)
	_val_best = _stat_cell(grid, Loc.t("best"), UiKit.C_GREEN)
	var bpad := Control.new()
	bpad.custom_minimum_size = Vector2(0, inset.y)
	bv.add_child(bpad)

	# ---- Toko (overlay paling atas)
	_shop = UpgradeShop.new()
	_shop.sfx = _sfx
	_shop.closed.connect(_refresh_hud)
	add_child(_shop)
	_lang_picker = LanguagePicker.new()
	_lang_picker.sfx = _sfx
	add_child(_lang_picker)


func _build_result() -> void:
	var cc := CenterContainer.new()
	cc.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	cc.mouse_filter = Control.MOUSE_FILTER_IGNORE
	cc.visible = false
	_play.add_child(cc)
	_result_box = cc

	_result_panel = PanelContainer.new()
	_result_panel.custom_minimum_size = Vector2(380, 0)
	_result_panel.add_theme_stylebox_override("panel", UiKit.style(Color("1d1a24f2"), 26, UiKit.C_YELLOW, 4, 18))
	cc.add_child(_result_panel)

	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 6)
	_result_panel.add_child(v)
	_res_title = UiKit.label(Loc.t("time_up"), 30, UiKit.C_YELLOW, 6)
	v.add_child(_res_title)
	_res_record = UiKit.label(Loc.t("new_record"), 24, UiKit.C_GREEN, 5)
	v.add_child(_res_record)
	_res_burgers = UiKit.label("0", 76, UiKit.C_GREEN, 8)
	v.add_child(_res_burgers)
	_res_caption = UiKit.label(Loc.t("cap_burger"), 14, Color("b9aed0"))
	v.add_child(_res_caption)
	_res_coins = UiKit.label("", 22, Color("ffe27a"), 4)
	v.add_child(_res_coins)
	_res_xp = UiKit.label("", 22, Color("c9a7ff"), 4)
	v.add_child(_res_xp)
	_res_gems = UiKit.label("", 22, Color("5dd6ff"), 4)
	v.add_child(_res_gems)
	_res_level = UiKit.label("", 26, UiKit.C_GREEN, 5)
	v.add_child(_res_level)

	var again := UiKit.button(Loc.t("play_again"), Color("34c759"), 28, Vector2(0, 62))
	again.pressed.connect(_on_play_again)
	v.add_child(again)
	var shop_btn := UiKit.button(Loc.t("shop_upgrade"), Color("4f8cff"), 20, Vector2(0, 48))
	shop_btn.pressed.connect(_open_shop)
	v.add_child(shop_btn)
	_blockers.append_array([again, shop_btn])
