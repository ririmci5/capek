extends Control
## LanguagePicker — overlay pilih bahasa (16 bahasa, nama asli masing-masing).
## Setelah memilih, scene dimuat ulang supaya semua teks memakai bahasa baru.

const UiKit := preload("res://scripts/ui_kit.gd")

var sfx = null


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	visible = false
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.75)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(dim)

	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	for side in ["left", "right"]:
		margin.add_theme_constant_override("margin_" + side, 18)
	margin.add_theme_constant_override("margin_top", 70)
	margin.add_theme_constant_override("margin_bottom", 50)
	add_child(margin)

	var panel := PanelContainer.new()
	panel.add_theme_stylebox_override("panel", UiKit.style(Color("251f2e"), 26, UiKit.C_YELLOW, 4, 16))
	margin.add_child(panel)
	var v := VBoxContainer.new()
	v.add_theme_constant_override("separation", 10)
	panel.add_child(v)

	var head := HBoxContainer.new()
	v.add_child(head)
	var title := UiKit.label(Loc.t("language"), 28, UiKit.C_YELLOW, 6, HORIZONTAL_ALIGNMENT_LEFT)
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	head.add_child(title)
	var close := UiKit.button("X", Color("e5483c"), 24, Vector2(56, 48))
	close.pressed.connect(close_picker)
	head.add_child(close)

	var scroll := ScrollContainer.new()
	scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	v.add_child(scroll)
	var grid := GridContainer.new()
	grid.columns = 2
	grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	grid.add_theme_constant_override("h_separation", 8)
	grid.add_theme_constant_override("v_separation", 8)
	scroll.add_child(grid)
	for l in Loc.LANGS:
		var code: String = l[0]
		var active := code == Loc.lang
		var b := UiKit.button(str(l[1]), Color("34c759") if active else Color("4f8cff"), 18, Vector2(0, 56))
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		b.clip_text = true
		b.pressed.connect(_pick.bind(code))
		grid.add_child(b)


func open() -> void:
	visible = true


func close_picker() -> void:
	visible = false


func _pick(code: String) -> void:
	if sfx:
		sfx.click()
	if code == Loc.lang:
		close_picker()
		return
	Loc.set_language(code)
	get_tree().reload_current_scene()
